package com.example.gh.myapplication;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

public class Fragment1 extends Fragment {
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_fragment1, container, false);
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {

        //final Intent intent = new Intent();

              // 设置默认进来是tab 显示的页面
        //final Fragment fragment = new CoachList();
       // final Bundle bundle = new Bundle();
        ImageView image =  getActivity().findViewById(R.id.imageView2);
        super.onActivityCreated(savedInstanceState);
      //  android.widget.LinearLayout button = (LinearLayout) getActivity().findViewById(R.id.football_but);
            image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent1 =new Intent();
                    intent1.setClass(getActivity(),CoachList.class);
                    startActivity(intent1);
                }
            });

    }

    @Override
    public void onStart() {
        super.onStart();
    }

    public void onBackPressed() {
        Fragment fragment = new Fragment1();
        getActivity().getSupportFragmentManager().beginTransaction().add(R.id.container,
                fragment).commit();
    }

    
}
